/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarkovcalculator;

/**
 *
 * @author Jason Freeman
 */
public class Craft {
    
    private double roublesAnHour;
    private int craftCost;
    private int resultCost;
    
    private Item[] craftItems;
    private Item[] resultItems;
    private double time;
    
    public Craft(Item[] craftItems, double time, Item[] resultItems)
    {
        this.craftItems = craftItems;
        this.time = time;
        this.resultItems = resultItems;
        
        craftCost = 0;
        resultCost = 0;
        
        for (int i = 0; i < craftItems.length; i++)
        {
            craftCost += craftItems[i].getCost();
        }
        
        for (int i = 0; i < resultItems.length; i++)
        {
            resultCost += resultItems[i].getCost();
        }
        
        roublesAnHour = ((resultCost-craftCost)/(time/60));
    }
    

    public void setCraftItems(Item[] craftItems) {
        this.craftItems = craftItems;
    }

    public void setResultItems(Item[] resultItems) {
        this.resultItems = resultItems;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public double getRoublesAnHour() {
        return roublesAnHour;
    }

    public int getCraftCost() {
        return craftCost;
    }

    public Item[] getCraftItems() {
        return craftItems;
    }

    public Item[] getResultItems() {
        return resultItems;
    }

    public double getTime() {
        return time;
    }
    
    public int getResultCost() {
        return resultCost;
    }
        
}
