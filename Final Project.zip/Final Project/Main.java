/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarkovcalculator;

import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author Jason Freeman
 */
public class Main {

    public static void main(String[] args) 
    {
        
        
        ArrayList<Item> items = new ArrayList<>();
        
        items.add(new Item("Working LCD", 10000));              //0
        items.add(new Item("Screwdriver", 5500));
        items.add(new Item("Broken LCD", 12500));
        items.add(new Item("Flat screwdriver", 11000));
        items.add(new Item("DVD drive", 7500));                    //4
        items.add(new Item("Printed circuit board", 20000));
        items.add(new Item("T-Shaped Plug", 5500));
        items.add(new Item("Wires", 15000));
        items.add(new Item("Tape", 12500));
        items.add(new Item("Powercord", 22500));                //9
        items.add(new Item("Blue Gunpowder", 20000));
        items.add(new Item("Green Gunpowder", 75000));
        items.add(new Item("Matches", 15000));
        items.add(new Item("Red Gunpowder", 75000));
        items.add(new Item("Damaged Hard Drive", 11000));       //14
        items.add(new Item("Magnet", 20000));
        items.add(new Item("Gas Analyzer", 15000));
        items.add(new Item("Nails", 20000));
        items.add(new Item("5.45x39 mm PS", 81));
        items.add(new Item("12/70 8.5 Magnum Buckshot", 300));  //19
        items.add(new Item("Broken GPhone X", 22500));     
        items.add(new Item("Long Flat Screwdrier", 8500));
        items.add(new Item("Broken Gphone", 17000));
        items.add(new Item("40 mm VOG-25", 20000));
        items.add(new Item("UZRGM grenade fuze", 13500));       //24
        items.add(new Item("VOG-25 Khattabka grenade", 25000));
        items.add(new Item("Power Supply Unit", 25000));
        items.add(new Item("Capacitors", 13000));
        items.add(new Item("Powerbank", 40000));
        items.add(new Item("Rechargebale Battery", 10740));     //29
        items.add(new Item("RDG-2B Smoke Grenade", 9000));
        items.add(new Item("Zarya stun grenade", 8000));
        items.add(new Item("Electric drill", 15000));
        items.add(new Item("Electric motor", 40000));
        items.add(new Item("AA Battery", 5000));                //34
        items.add(new Item("Geiger-Muller counter", 16500));    //35
        items.add(new Item("M67 Hand grenade", 50000));
        items.add(new Item("OFZ 30x160mm Shell", 165000));
        items.add(new Item("Metal fuel tank", 250000));
        items.add(new Item("12/70 Flechette", 130));
        items.add(new Item("PC CPU", 20000));                   //40
        items.add(new Item("RAM", 12000));
        items.add(new Item("Military circuit board", 40000));
        items.add(new Item("7.62x54R SNB", 375));
        items.add(new Item("9x39 mm SP-6", 650));
        items.add(new Item("7.62x39 m PS", 91));                //45
        items.add(new Item(".366 AP", 700));
        items.add(new Item("9x19 mm Pst gzh", 68));
        items.add(new Item("9x19 mm AP 6.3", 1300));
        items.add(new Item("NIXXOR lens", 20000));
        items.add(new Item("Military thermal vision module Iridium", 100000)); //50
        items.add(new Item("Virtex programmable processor", 200000));
        items.add(new Item("SAS drive", 43000));
        items.add(new Item("FLIR RS-32 2.25-9x 35mm 60hz thermal riflescope", 700000));
        items.add(new Item("TP-200 TNT brick", 23000));
        items.add(new Item("RGD-5 hand grenade", 12000));       //55
        items.add(new Item("12/70 AP-20 slug", 1100));
        items.add(new Item("9x19 mm RIP", 900));
        items.add(new Item("SurvL Survivor Lighter", 14000));
        items.add(new Item("23x75mm Star", 20000));
        items.add(new Item("7.62x39 mm BP", 1255));             //60
        items.add(new Item("9x21 mm SP13", 381));
        items.add(new Item("Leatherman Multitool", 23556));
        items.add(new Item("9x39 mm 7N9 SPP", 1150));
        items.add(new Item("Military power filter", 60000));
        items.add(new Item("9x39 mm 7n12 BP", 2500));           //65
        items.add(new Item("Radiator helix", 30000));
        items.add(new Item("7.52x51 mm M61", 2400));
        items.add(new Item("Can of thermite", 120000));
        items.add(new Item("5.56x45 mm M995", 2600));
        items.add(new Item("5.45x39 mm 7N39 Igolnik", 1500));   //70
        items.add(new Item("9x19 mm 7n31", 2500));
        
        ArrayList<Craft> crafts = new ArrayList<>();
        
        Item[] craft1 = new Item[4];
        for (int i = 0; i < 3; i++) craft1[i] = items.get(0);
        craft1[3] = items.get(1);
        Item[] result1 = new Item[3];
        for (int i = 0; i < 3; i++) result1[i] = items.get(2);
        crafts.add(new Craft(craft1,22,result1));
        
        Item[] craft2 = new Item[2];
        craft2[0] = items.get(3);
        craft2[1] = items.get(4);
        Item[] result2 = new Item[2];
        result2[0] = items.get(5);
        result2[1] = items.get(5);
        crafts.add(new Craft(craft2, 33, result2));
        
        Item[] craft3 = new Item[5];
        craft3[0] = items.get(6);
        craft3[1] = items.get(6);
        craft3[2] = items.get(7);
        craft3[3] = items.get(7);
        craft3[4] = items.get(8);
        Item[] result3 = new Item[2];
        result3[0] = items.get(9);
        result3[1] = items.get(9);
        crafts.add(new Craft(craft3, 35, result3));
        
        Item[] craft4 = new Item[3];
        craft4[0] = items.get(10);
        craft4[1] = items.get(11);
        craft4[2] = items.get(12);
        Item[] result4 = new Item[2];
        result4[0] = items.get(13);
        result4[1] = items.get(13);
        crafts.add(new Craft(craft4, 36, result4));
        
        Item[] craft5 = new Item[1];
        craft5[0] = items.get(14);
        Item[] result5 = new Item[1];
        result5[0] = items.get(15);
        crafts.add(new Craft(craft5, 43, result5));
        
        Item[] craft6 = new Item[2];
        craft6[0] = items.get(16);
        craft6[1] = items.get(1);
        Item[] result6 = new Item[2];
        result6[0] = items.get(5);
        result6[1] = items.get(5);
        crafts.add(new Craft(craft6, 48, result6));
        
        Item[] craft7 = new Item[2];
        craft7[0] = items.get(17);
        craft7[1] = items.get(9);
        Item[] result7 = new Item[1];
        result7[0] = items.get(6);
        crafts.add(new Craft(craft7, 57, result7));
        
        Item[] craft8 = new Item[70];
        for(int i = 0; i < 70; i++) craft8[i] = items.get(18);
        Item[] result8 = new Item[1];
        result8[0] = items.get(10);
        crafts.add(new Craft(craft8, 89, result8));
        
        Item[] craft9 = new Item[2];
        craft9[0] = items.get(10);
        craft9[1] = items.get(12);
        Item[] result9 = new Item[120];
        for(int i = 0; i < 120; i++) result9[i] = items.get(19);
        crafts.add(new Craft(craft9, 92, result9));
                
        Item[] craft10 = new Item[3];
        craft10[0] = items.get(20);
        craft10[1] = items.get(2);
        craft10[2] = items.get(21);
        Item[] result10 = new Item[1];
        result10[0] = items.get(22);
        crafts.add(new Craft(craft10, 100,result10));
        
        Item[] craft11 = new Item[10];
        for(int i = 0; i <5; i++) craft11[i] = items.get(23);
        for(int i = 5; i <10; i++) craft11[i] = items.get(24);
        Item[] result11 = new Item[8];
        for(int i = 0; i < 8; i++) result11[i] = items.get(25);
        crafts.add(new Craft(craft11, 100, result11));
            
        Item[] craft12 = new Item[2];
        for(int i = 0; i < 2; i++) craft12[i] = items.get(9);
        Item[] result12 = new Item[8];
        for(int i = 0; i < 8; i++) result12[i] = items.get(7);
        crafts.add(new Craft(craft12, 118, result12));
        
        Item[] craft13 = new Item[2];
        craft13[0] = items.get(26);
        craft13[1] = items.get(2);
        Item[] result13 = new Item[8];
        for(int i = 0; i < 8; i++) result13[i] = items.get(27);
        crafts.add(new Craft(craft13, 124, result13));
        
        Item[] craft14 = new Item[151];
        for (int i = 0; i < 50; i++) craft14[i] = items.get(44);
        for (int i = 50; i < 150; i++) craft14[i] = items.get(45);
        craft14[150] = items.get(10);
        Item[] result14 = new Item[100];
        for (int i = 0; i < 100; i++) result14[i] = items.get(46);
        crafts.add(new Craft(craft14, 237, result14));
        
        Item[] craft15 = new Item[202];
        for (int i = 0; i < 200; i++) craft15[i] = items.get(47);
        craft15[200] = items.get(13);
        craft15[201] = items.get(14);
        Item[] result15 = new Item[200];
        for (int i = 0; i < 200; i++) result15[i] = items.get(48);
        crafts.add(new Craft(craft15, 308, result15));
        
        Item[] craft16 = new Item[9];
        craft16[0] = items.get(49);
        craft16[1] = items.get(49);
        craft16[2] = items.get(50);
        craft16[3] = items.get(50);
        craft16[4] = items.get(51);
        craft16[5] = items.get(52);
        craft16[6] = items.get(52);
        craft16[7] = items.get(49);
        craft16[8] = items.get(28);
        Item[] result16 = new Item[1];
        result16[0] = items.get(53);
        crafts.add(new Craft(craft16, 370, result16));
        
        Item[] craft17 = new Item[3];
        craft17[0] = items.get(13);
        craft17[1] = items.get(14);
        craft17[2] = items.get(17);
        Item[] result17 = new Item[120];
        for (int i = 0; i < 120; i++) result17[i] = items.get(56);
        crafts.add(new Craft(craft17, 148, result17));
        
        Item[] craft18 = new Item[5];
        for (int i = 0; i < 4; i++) craft18[i] = items.get(7);
        craft18[4] = items.get(13);
        Item[] result18 = new Item[180];
        for (int i = 0; i < 180; i++) result18[i] = items.get(57);
        crafts.add(new Craft(craft18, 175, result18));
        
        Item[] craft19 = new Item[8];
        for (int i = 0; i < 5; i++) craft19[i] = items.get(58);
        craft19[5] = items.get(11);
        craft19[6] = items.get(10);
        craft19[7] = items.get(31);
        Item[] result19 = new Item[7];
        for (int i = 0; i < 7; i++) result19[i] = items.get(59);
        crafts.add(new Craft(craft19, 208, result19));
        
        Item[] craft20 = new Item[3];
        craft20[0] = items.get(11);
        craft20[1] = items.get(11);
        craft20[2] = items.get(10);
        Item[] result20 = new Item[260];
        for (int i = 0; i < 260; i++) result20[i] = items.get(60);
        crafts.add(new Craft(craft20, 350, result20));
        
        Item[] craft21 = new Item[152];
        for (int i = 0; i < 150; i++) craft21[i] = items.get(61);
        craft21[150] = items.get(10);
        craft21[151] = items.get(62);
        Item[] result21 = new Item[200];
        for (int i = 0; i < 200; i++) result21[i] = items.get(63);
        crafts.add(new Craft(craft21, 363, result21));
        
        Item[] craft22 = new Item[4];
        craft22[0] = items.get(64);
        craft22[1] = items.get(64);
        craft22[2] = items.get(13);
        craft22[3] = items.get(13);
        Item[] result22 = new Item[160];
        for (int i = 0; i < 160; i++) result22[i] = items.get(65);
        crafts.add(new Craft(craft22, 387, result22));
        
        Item[] craft23 = new Item[8];
        for(int i = 0; i < 6; i++) craft23[i] = items.get(13);
        craft23[6] = items.get(66);
        craft23[7] = items.get(66);
        Item[] result23 = new Item[300];
        for (int i = 0; i < 300; i++) result23[i] = items.get(67);
        crafts.add(new Craft(craft23, 399, result23));
        
        Item[] craft24 = new Item[4];
        craft24[0] = items.get(11);
        craft24[1] = items.get(37);
        craft24[2] = items.get(37);
        craft24[3] = items.get(68);
        Item[] result24 = new Item[300];
        for (int i = 0; i < 300; i++) result24[i] = items.get(69);
        crafts.add(new Craft(craft24, 460, result24));
        
        Item[] craft25 = new Item[10];
        for (int i = 0; i <5; i++) craft25[i] = items.get(30);
        craft25[5] = items.get(13);
        craft25[6] = items.get(14);
        craft25[7] = items.get(11);
        craft25[8] = items.get(54);
        craft25[9] = items.get(54);
        Item[] result25 = new Item[2];
        for (int i = 0; i < 2; i++) result25[i] = items.get(37);
        crafts.add(new Craft(craft25, 483, result25));
        
        Item[] craft26 = new Item[6];
        craft26[0] = items.get(10);
        craft26[1] = items.get(10);
        craft26[2] = items.get(11);
        craft26[3] = items.get(11);
        craft26[4] = items.get(13);
        craft26[5] = items.get(13);
        Item[] result26 = new Item[260];
        for (int i = 0; i < 260; i++) result26[i] = items.get(70);
        crafts.add(new Craft(craft26, 488, result26));
        
        Item[] craft27 = new Item[12];
        for(int i = 0; i < 4; i++) craft27[i] = items.get(10);
        for(int i = 4; i < 8; i++) craft27[i] = items.get(17);
        for(int i = 8; i < 11; i++) craft27[i] = items.get(11);
        craft27[11] = items.get(68);
        Item[] result27 = new Item[300];
        for(int i = 0; i < 300; i++) result27[i] = items.get(71);
        crafts.add(new Craft(craft27, 518, result27));
        
        Scanner scanner = new Scanner(System.in);
        
        
        System.out.println("What is the maximum amount of roubles you're willing to spend on a craft?");
        int answer1 = Integer.parseInt(scanner.nextLine());
        System.out.println("How many minutes at the minimum would you like it to take?");
        int answer2 = Integer.parseInt(scanner.nextLine());
        System.out.println("Do you care more about roubles per hour(insert '1') or max profit(insert '2')?");
        int answer3 = Integer.parseInt(scanner.nextLine());
        
        
        
        
        
        
        double max = crafts.get(0).getRoublesAnHour();
        Craft bestcraft = crafts.get(0);
        for(int i = 0; i < 27; i++)
        {
            if(crafts.get(i).getCraftCost() < answer1)
            {
                if(crafts.get(i).getTime() > answer2)
                {
                    if(answer3 == 1)
                    {
                        if(crafts.get(i).getRoublesAnHour() > max)
                        {
                            max = crafts.get(i).getResultCost();
                            bestcraft = crafts.get(i);
                        }
                    }
                    
                    if(answer3 == 0)
                    {
                        if(crafts.get(i).getResultCost() > max)
                        {
                            max = crafts.get(i).getResultCost();
                            bestcraft = crafts.get(i);
                        }
                    }
                }
            }
        }
        System.out.print("With your settings, the most optimal craft is the craft that results in: ");
        System.out.println(bestcraft.getResultItems()[0].getName());
        System.out.println("This craft will cost you: " + bestcraft.getCraftCost() + " Roubles");
        System.out.println("This craft will give you: " + bestcraft.getResultCost() + " Roubles");
        System.out.println("And will take: " + bestcraft.getTime() + " minutes");
        System.out.println("For a grand total of: " + bestcraft.getRoublesAnHour() + " Roubles per hour");
    }
    
}
