/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tarkovcalculator;

/**
 *
 * @author Jason Freeman
 */
public class Main {

    public static void main(String[] args) 
    {
        Item item1 = new Item("Broken GPhone", 10000);
        Item item2 = new Item("Broken GPhone X", 15000);
        Item item3 = new Item("SSD Drive", 50000);
        
        double time = 34.25;
        
        Item item4 = new Item("Flash Drive", 30000);
        Item item5 = new Item("Flash Drive", 30000);
        Item item6 = new Item("Flash Drive", 30000);
        
        Item[] need = {item1,item2,item3};
        Item[] craft = {item4,item5,item6};
        
        Craft theCraft = new Craft(need, time, craft);
        
        System.out.println(theCraft.getRoublesAnHour());
    }
    
}
